package org.Gh0st1yAnge1;

import org.Gh0st1yAnge1.client_commands.write.Insert;
import org.Gh0st1yAnge1.client_commands.write.Update;
import org.Gh0st1yAnge1.exceptions.InputCancelledException;
import org.Gh0st1yAnge1.manager.ClientCommandManager;
import org.Gh0st1yAnge1.manager.InputManager;
import org.Gh0st1yAnge1.model.Route;
import org.Gh0st1yAnge1.request_and_response.CommandType;
import org.Gh0st1yAnge1.request_and_response.Request;
import org.Gh0st1yAnge1.request_and_response.Response;
import org.Gh0st1yAnge1.utils.RouteBuilder;
import org.Gh0st1yAnge1.utils.TcpUtil;

import java.io.*;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

public class ClientApp {

    private static final String HOST               = "localhost";
    private static final int    PORT               = 12345;
    private static final long   RECONNECT_DELAY_MS = 3000;

    private static String  sessionLogin    = null;
    private static String  sessionPassword = null;
    private static boolean isAuthenticated = false;

    private static SocketChannel channel;

    private static InputManager        inputManager;
    private static RouteBuilder        routeBuilder;
    private static ClientCommandManager commandManager;

    public static void main(String[] args) {
        Runtime.getRuntime().addShutdownHook(new Thread(ClientApp::closeQuietly));

        inputManager   = new InputManager();
        routeBuilder   = new RouteBuilder(inputManager);
        commandManager = new ClientCommandManager(inputManager, routeBuilder);

        ensureConnected();

        String line;
        System.out.print("> ");
        while ((line = inputManager.readline()) != null) {
            line = line.trim();
            if (line.isEmpty()) { System.out.print("> "); continue; }

            String name = line.split("\\s+", 2)[0];
            String arg  = line.contains(" ") ? line.substring(line.indexOf(' ') + 1).trim() : null;

            if (name.equals("exit")) break;

            if (name.equals("execute_script")) {
                commandManager.executeScript(arg, ClientApp::scriptSender);
                System.out.print("> ");
                continue;
            }

            Request request = commandManager.execute(line);
            if (request == null) { System.out.print("> "); continue; }

            CommandType type = request.commandType();
            boolean isAuth = type == CommandType.LOGIN || type == CommandType.REGISTER || type == CommandType.LOGOUT;

            if (!isAuthenticated && !isAuth && type != CommandType.HELP) {
                System.out.println("You must login or register first! Use: login <login> <password>");
                System.out.print("> ");
                continue;
            }

            if (type == CommandType.CHECK_INSERT_KEY || type == CommandType.CHECK_UPDATE_KEY) {
                handleInsertOrUpdate(type, arg);
                System.out.print("> ");
                continue;
            }

            Request toSend = isAuth ? request : withCreds(request);
            Response resp  = communicate(toSend);
            if (resp != null) {
                printResponse(resp);
                applyAuthSideEffects(request, resp);
            }
            System.out.print("> ");
        }

        closeQuietly();
    }

    private static void handleInsertOrUpdate(CommandType checkType, String arg) {
        boolean isInsert = (checkType == CommandType.CHECK_INSERT_KEY);

        Response checkResp = communicate(withCreds(new Request(checkType, arg, null)));
        if (checkResp == null) return;
        printResponse(checkResp);
        if (!checkResp.success()) return;

        Request built;
        try {
            built = isInsert
                    ? new Insert(routeBuilder).execute(arg)
                    : new Update(routeBuilder).execute(arg);
        } catch (InputCancelledException e) {
            System.out.println("Route building cancelled.");
            return;
        }

        Response resp = communicate(withCreds(built));
        if (resp != null) printResponse(resp);
    }

    private static Response scriptSender(Request request) throws IOException, ClassNotFoundException {
        boolean isAuth = request.commandType() == CommandType.LOGIN || request.commandType() == CommandType.REGISTER || request.commandType() == CommandType.LOGOUT;
        Request toSend = isAuth ? request : withCreds(request);
        Response resp  = communicate(toSend);
        if (resp != null) applyAuthSideEffects(request, resp);
        return resp;
    }

    private static Request withCreds(Request r) {
        return new Request(r.commandType(), r.argument(), r.route(), sessionLogin, sessionPassword);
    }

    private static void applyAuthSideEffects(Request req, Response resp) {
        if (resp == null) return;
        switch (req.commandType()) {
            case LOGIN -> {
                if (resp.success()) {
                    sessionLogin    = req.login();
                    sessionPassword = req.password();
                    isAuthenticated = true;
                }
            }
            case REGISTER -> {
                if (resp.success())
                    System.out.println("Now you can login with: login <login> <password>");
            }
            case LOGOUT -> {
                sessionLogin    = null;
                sessionPassword = null;
                isAuthenticated = false;
            }
            default -> {}
        }
    }

    private static void printResponse(Response resp) {
        if (resp.message() != null) System.out.println(resp.message());
        if (resp.collection() != null) {
            if (resp.collection().isEmpty()) {
                System.out.println("(collection is empty)");
            } else {
                for (Route route : resp.collection()) System.out.println(route);
            }
        }
    }

    private static Response communicate(Request request) {
        try {
            ensureConnected();
            send(request);
            return receive();
        } catch (IOException e) {
            System.out.println("Connection lost: " + e.getMessage());
            closeQuietly();
            return null;
        } catch (ClassNotFoundException e) {
            System.out.println("Protocol error: " + e.getMessage());
            return null;
        }
    }

    private static void ensureConnected() {
        while (!isConnected()) {
            try {
                channel = SocketChannel.open();
                channel.configureBlocking(false);
                channel.connect(new InetSocketAddress(HOST, PORT));

                while (!channel.finishConnect()) {
                    Thread.sleep(10);
                }

                System.out.println("Connected to server.");
            } catch (IOException e) {
                System.out.println("Server unavailable. Retrying in " + RECONNECT_DELAY_MS + " ms...");
                closeQuietly();
                try { Thread.sleep(RECONNECT_DELAY_MS); } catch (InterruptedException ignored) {}
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
        }
    }

    private static boolean isConnected() {
        return channel != null && channel.isOpen() && channel.isConnected();
    }

    private static void send(Request request) throws IOException {
        byte[] data = serialize(request);

        int offset = 0;
        while (offset < data.length) {
            int chunkLen = Math.min(TcpUtil.CHUNK_SIZE, data.length - offset);

            writeAll(intToBytes(chunkLen));
            writeAll(data, offset, chunkLen);

            offset += chunkLen;
        }

        writeAll(intToBytes(0));
    }

    private static void writeAll(byte[] bytes) throws IOException {
        writeAll(bytes, 0, bytes.length);
    }

    private static void writeAll(byte[] bytes, int offset, int length) throws IOException {
        ByteBuffer buf = ByteBuffer.wrap(bytes, offset, length);
        while (buf.hasRemaining()) {
            channel.write(buf);
        }
    }

    private static Response receive() throws IOException, ClassNotFoundException {
        ByteArrayOutputStream acc = new ByteArrayOutputStream();

        while (true) {
            byte[] lenBytes = readExactly(4);
            int chunkLen = ByteBuffer.wrap(lenBytes).getInt();

            if (chunkLen == 0) break;
            if (chunkLen < 0) throw new IOException("Invalid chunk size: " + chunkLen);

            byte[] chunk = readExactly(chunkLen);
            acc.write(chunk);
        }

        return (Response) deserialize(acc.toByteArray());
    }

    private static byte[] readExactly(int n) throws IOException {
        ByteBuffer buf = ByteBuffer.allocate(n);
        while (buf.hasRemaining()) {
            int read = channel.read(buf);
            if (read == -1) throw new EOFException("Server closed connection");
            if (read == 0) {
                try { Thread.sleep(1); } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    throw new IOException("Interrupted while reading", e);
                }
            }
        }
        return buf.array();
    }

    private static byte[] intToBytes(int value) {
        return ByteBuffer.allocate(4).putInt(value).array();
    }

    private static byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (ObjectOutputStream oos = new ObjectOutputStream(baos)) {
            oos.writeObject(obj);
        }
        return baos.toByteArray();
    }

    private static Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(data))) {
            return ois.readObject();
        }
    }

    private static void closeQuietly() {
        try { if (channel != null) channel.close(); } catch (IOException ignored) {}
        channel = null;
    }
}