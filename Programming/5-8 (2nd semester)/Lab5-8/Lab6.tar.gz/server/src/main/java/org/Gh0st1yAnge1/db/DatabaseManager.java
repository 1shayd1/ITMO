package org.Gh0st1yAnge1.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseManager {

    private final String url;
    private final String user;
    private final String password;

    public DatabaseManager(String url, String user, String password) throws SQLException {
        this.url = url;
        this.user = user;
        this.password = password;
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("PostgreSQL JDBC Driver not found", e);
        }
        initTables();
    }

    private void initTables() throws SQLException {
        String createUsers = """
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                username VARCHAR(64) UNIQUE NOT NULL,
                password_hash VARCHAR(512) NOT NULL
            );
        """;

        String createRoutes = """
            CREATE TABLE IF NOT EXISTS routes (
                id SERIAL PRIMARY KEY,
                key_id INTEGER UNIQUE NOT NULL,
                name TEXT NOT NULL,
                coord_x DOUBLE PRECISION,
                coord_y INTEGER,
                creation_date TIMESTAMP,
                from_x DOUBLE PRECISION,
                from_y DOUBLE PRECISION,
                from_z INTEGER,
                from_name TEXT,
                to_x FLOAT,
                to_y DOUBLE PRECISION,
                to_z INTEGER,
                to_name TEXT,
                distance BIGINT,
                owner_id INTEGER REFERENCES users(id) ON DELETE CASCADE
            );
        """;

        try (Connection conn = getConnection();
             Statement st = conn.createStatement()) {
            st.execute(createUsers);
            st.execute(createRoutes);
            System.out.println("Users and Routes tables are created/checked");
        }
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    public void close() {
        System.out.println("DatabaseManager closed (DriverManager)");
    }
}