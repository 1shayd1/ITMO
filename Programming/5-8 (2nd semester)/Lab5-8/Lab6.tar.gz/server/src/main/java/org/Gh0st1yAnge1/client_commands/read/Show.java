package org.Gh0st1yAnge1.client_commands.read;

import org.Gh0st1yAnge1.client_commands.ClientCommand;
import org.Gh0st1yAnge1.manager.CollectionManager;
import org.Gh0st1yAnge1.model.Route;
import org.Gh0st1yAnge1.request_and_response.Response;

public class Show implements ClientCommand {

    private final CollectionManager collectionManager;

    public Show(CollectionManager collectionManager) {
        this.collectionManager = collectionManager;
    }

    @Override
    public Response execute(String arg, Route route, Long userId) {
        if (arg != null) {
            return new Response(false, "Usage: show");
        }
        // FIX: раньше коллекция считалась, но НЕ клалась в Response, поэтому клиент
        // ничего не видел. Теперь отдаём список (работаем с коллекцией в памяти).
        return new Response(true, "All available routes:", collectionManager.showCollection());
    }

    @Override
    public String getName() {
        return "show";
    }

    @Override
    public String getDescription() {
        return "shows all collection elements";
    }
}
