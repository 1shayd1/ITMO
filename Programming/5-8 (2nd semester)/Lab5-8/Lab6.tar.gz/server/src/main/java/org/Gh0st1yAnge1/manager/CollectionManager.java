package org.Gh0st1yAnge1.manager;

import org.Gh0st1yAnge1.model.Route;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * Потокобезопасная коллекция на основе ConcurrentHashMap.
 * Вариант синхронизации: потокобезопасные аналоги коллекции из java.util.concurrent.
 */
public class CollectionManager {

    // ConcurrentHashMap — потокобезопасный аналог HashMap из java.util.concurrent
    private final ConcurrentHashMap<Integer, Route> collection = new ConcurrentHashMap<>();
    private final LocalDate initializationDate = LocalDate.now();

    public void load(Map<Integer, Route> loaded) {
        collection.clear();
        if (loaded != null) collection.putAll(loaded);
    }

    public boolean checkKey(int key) {
        return collection.containsKey(key);
    }

    public void insert(Integer key, Route route) {
        collection.put(key, route);
    }

    public void update(Integer key, Route route) {
        collection.put(key, route);
    }

    public boolean removeByKey(Integer key) {
        return collection.remove(key) != null;
    }

    public int removeGreaterKey(Integer key) {
        List<Integer> toRemove = collection.keySet().stream()
                .filter(k -> k > key)
                .collect(Collectors.toList());
        toRemove.forEach(collection::remove);
        return toRemove.size();
    }

    public int removeGreater(Route ref) {
        List<Integer> toRemove = collection.entrySet().stream()
                .filter(e -> e.getValue().compareTo(ref) > 0)
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());
        toRemove.forEach(collection::remove);
        return toRemove.size();
    }

    public boolean replaceIfLower(Integer key, Route newRoute) {
        // computeIfPresent + compare — атомарно через compute
        boolean[] replaced = {false};
        collection.compute(key, (k, current) -> {
            if (current != null && current.compareTo(newRoute) > 0) {
                replaced[0] = true;
                return newRoute;
            }
            return current;
        });
        return replaced[0];
    }

    public void clear() {
        collection.clear();
    }

    public Map<Integer, Route> getMap() {
        return Collections.unmodifiableMap(collection);
    }

    public List<Route> showCollection() {
        return collection.values().stream()
                .sorted(Comparator.comparing(Route::getTo,
                        Comparator.nullsLast(Comparator.naturalOrder())))
                .collect(Collectors.toList());
    }

    public double averageOfDistance() {
        return collection.values().stream()
                .mapToDouble(Route::getDistance)
                .average()
                .orElse(0.0);
    }

    public long countByDistance(double distance) {
        return collection.values().stream()
                .filter(r -> r.getDistance() == distance)
                .count();
    }

    public List<Route> filterLessThanDistance(double distance) {
        return collection.values().stream()
                .filter(r -> r.getDistance() < distance)
                .collect(Collectors.toList());
    }

    public String info() {
        return "Collection type: ConcurrentHashMap (java.util.concurrent)" +
                "\nSize: " + collection.size() +
                "\nInitialization date: " + initializationDate;
    }
}